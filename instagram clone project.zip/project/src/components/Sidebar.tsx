import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search, Compass, Film, Heart, PlusSquare, MessageCircle, Menu, Instagram, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  onSearchOpen: () => void;
}

export default function Sidebar({ onSearchOpen }: SidebarProps) {
  const { logout, user } = useAuth();

  return (
    <div className="fixed h-screen w-64 border-r border-gray-200 p-5 flex flex-col bg-white">
      <div className="py-6">
        <Link to="/" className="flex items-center space-x-2">
          <Instagram className="w-8 h-8" />
          <span className="text-xl font-semibold">Instagram</span>
        </Link>
      </div>
      
      <nav className="flex-1">
        <ul className="space-y-4">
          <li>
            <Link to="/" className="flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg">
              <Home className="w-6 h-6" />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <button
              onClick={onSearchOpen}
              className="w-full flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg"
            >
              <Search className="w-6 h-6" />
              <span>Search</span>
            </button>
          </li>
          <li>
            <Link to="/explore" className="flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg">
              <Compass className="w-6 h-6" />
              <span>Explore</span>
            </Link>
          </li>
          <li>
            <Link to="/reels" className="flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg">
              <Film className="w-6 h-6" />
              <span>Reels</span>
            </Link>
          </li>
          <li>
            <button className="w-full flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg">
              <MessageCircle className="w-6 h-6" />
              <span>Messages</span>
            </button>
          </li>
          <li>
            <button className="w-full flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg">
              <Heart className="w-6 h-6" />
              <span>Notifications</span>
            </button>
          </li>
          <li>
            <button className="w-full flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg">
              <PlusSquare className="w-6 h-6" />
              <span>Create</span>
            </button>
          </li>
          <li>
            <div className="flex items-center space-x-4 p-2">
              <img
                src={user?.image || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop'}
                alt={user?.username || 'Profile'}
                className="w-6 h-6 rounded-full object-cover"
              />
              <span>{user?.username || 'Profile'}</span>
            </div>
          </li>
        </ul>
      </nav>
      
      <div className="mt-auto">
        <button
          onClick={logout}
          className="flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg w-full"
        >
          <LogOut className="w-6 h-6" />
          <span>Log out</span>
        </button>
        <button className="flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg w-full">
          <Menu className="w-6 h-6" />
          <span>More</span>
        </button>
      </div>
    </div>
  );
}