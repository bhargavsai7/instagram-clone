import React from 'react';

interface Suggestion {
  username: string;
  image: string;
  relation: string;
}

const suggestions: Suggestion[] = [
  {
    username: 'user4',
    image: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=150&h=150&fit=crop',
    relation: 'Followed by user1 + 3 more',
  },
  {
    username: 'user5',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    relation: 'Followed by user2 + 2 more',
  },
  // Add more suggestions as needed
];

export default function Suggestions() {
  return (
    <div className="mt-6">
      <div className="flex justify-between mb-4">
        <span className="text-gray-500 font-semibold">Suggestions For You</span>
        <button className="text-sm font-semibold">See All</button>
      </div>
      
      {suggestions.map((suggestion, index) => (
        <div key={index} className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <img
              src={suggestion.image}
              alt={suggestion.username}
              className="w-8 h-8 rounded-full object-cover"
            />
            <div className="ml-3">
              <div className="text-sm font-semibold">{suggestion.username}</div>
              <div className="text-xs text-gray-500">{suggestion.relation}</div>
            </div>
          </div>
          <button className="text-sm font-semibold text-blue-500">Follow</button>
        </div>
      ))}
    </div>
  );
}