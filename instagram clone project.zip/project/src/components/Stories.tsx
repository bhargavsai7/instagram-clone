import React from 'react';

interface Story {
  username: string;
  image: string;
}

const stories: Story[] = [
  {
    username: 'user1',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  },
  {
    username: 'user2',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
  },
  {
    username: 'user3',
    image: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=150&h=150&fit=crop',
  },
  // Add more stories as needed
];

export default function Stories() {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
      <div className="flex space-x-4 overflow-x-auto">
        {stories.map((story, index) => (
          <div key={index} className="flex flex-col items-center space-y-1 flex-shrink-0">
            <div className="w-16 h-16 rounded-full ring-2 ring-pink-500 p-0.5">
              <img
                src={story.image}
                alt={story.username}
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            <span className="text-xs">{story.username}</span>
          </div>
        ))}
      </div>
    </div>
  );
}