import React, { useState } from 'react';
import { X, Search as SearchIcon } from 'lucide-react';

interface SearchProps {
  onClose: () => void;
}

const searchResults = [
  {
    username: 'johndoe',
    name: 'John Doe',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
  },
  {
    username: 'janedoe',
    name: 'Jane Doe',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  },
];

export default function Search({ onClose }: SearchProps) {
  const [query, setQuery] = useState('');

  return (
    <div className="fixed inset-0 bg-white z-50">
      <div className="max-w-md mx-auto p-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Search</h2>
          <button onClick={onClose}>
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="relative mb-6">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-lg focus:outline-none"
          />
        </div>
        
        {query && (
          <div className="space-y-4">
            {searchResults.map((result, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                <img
                  src={result.image}
                  alt={result.username}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="font-semibold">{result.username}</div>
                  <div className="text-gray-500 text-sm">{result.name}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}