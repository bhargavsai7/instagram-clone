import React from 'react';

const exploreImages = [
  'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=600&h=600&fit=crop',
  'https://images.unsplash.com/photo-1682687221038-404670f09ef1?w=600&h=600&fit=crop',
  'https://images.unsplash.com/photo-1682687982360-c0295d84f0e4?w=600&h=600&fit=crop',
  'https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=600&h=600&fit=crop',
  'https://images.unsplash.com/photo-1682687982185-531d09ec56fc?w=600&h=600&fit=crop',
  'https://images.unsplash.com/photo-1682687218147-9806132dc697?w=600&h=600&fit=crop',
];

export default function Explore() {
  return (
    <div className="grid grid-cols-3 gap-1">
      {exploreImages.map((image, index) => (
        <div key={index} className="aspect-square relative group cursor-pointer">
          <img
            src={image}
            alt={`Explore ${index + 1}`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200" />
        </div>
      ))}
    </div>
  );
}