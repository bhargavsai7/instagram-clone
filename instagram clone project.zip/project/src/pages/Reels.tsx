import React from 'react';
import { Heart, MessageCircle, Send, Bookmark } from 'lucide-react';

const reels = [
  {
    username: 'johndoe',
    userImage: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
    video: 'https://example.com/video1.mp4', // This is a placeholder URL
    caption: 'Check out this amazing sunset! 🌅 #reels #nature',
    likes: 5678,
  },
  {
    username: 'janedoe',
    userImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    video: 'https://example.com/video2.mp4', // This is a placeholder URL
    caption: 'Dancing in the rain 💃 #dance #reels',
    likes: 3456,
  },
];

export default function Reels() {
  return (
    <div className="max-w-[400px] mx-auto">
      {reels.map((reel, index) => (
        <div key={index} className="bg-black aspect-[9/16] relative mb-4">
          <div className="absolute inset-0 flex items-end">
            <div className="text-white p-4 w-full bg-gradient-to-t from-black/60 to-transparent">
              <div className="flex items-center mb-4">
                <img
                  src={reel.userImage}
                  alt={reel.username}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <span className="ml-2 font-semibold">{reel.username}</span>
              </div>
              
              <p className="mb-4">{reel.caption}</p>
              
              <div className="flex justify-between items-center">
                <div className="flex space-x-4">
                  <Heart className="w-6 h-6 text-white cursor-pointer" />
                  <MessageCircle className="w-6 h-6 text-white cursor-pointer" />
                  <Send className="w-6 h-6 text-white cursor-pointer" />
                </div>
                <Bookmark className="w-6 h-6 text-white cursor-pointer" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}