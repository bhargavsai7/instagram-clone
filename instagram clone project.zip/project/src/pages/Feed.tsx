import React from 'react';
import Stories from '../components/Stories';
import Post from '../components/Post';
import Suggestions from '../components/Suggestions';

const posts = [
  {
    username: 'johndoe',
    userImage: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=1200&h=800&fit=crop',
    caption: 'Beautiful sunset at the beach! 🌅 #nature #photography',
    likes: 1234,
  },
  {
    username: 'janedoe',
    userImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1682687221038-404670f09ef1?w=1200&h=800&fit=crop',
    caption: 'Coffee and code ☕️ #developer #coding',
    likes: 856,
  },
];

export default function Feed() {
  return (
    <div className="grid grid-cols-3 gap-8">
      <div className="col-span-2">
        <Stories />
        {posts.map((post, index) => (
          <Post key={index} {...post} />
        ))}
      </div>
      
      <div className="col-span-1">
        <Suggestions />
      </div>
    </div>
  );
}